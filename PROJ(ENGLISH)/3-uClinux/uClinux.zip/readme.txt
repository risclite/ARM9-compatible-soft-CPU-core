1, Unzip uclinux.zip into one directory, such as ./uclinux.
2, Run modelsim, and then "cd ./uclinux".
3, In modelsim window, input "source modelsim.tcl", or open modelsim.tcl to input one by one.

Then you can get all message of runing uclinux.